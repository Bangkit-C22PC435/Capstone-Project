package com.bangkit.tagme;

import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.zxing.WriterException;


public class QRGeneratorActivity extends AppCompatActivity {

    EditText qrinput1, qrinput2, qrinput3, qrinput4, qrinput5;
    Button generateqrBtn;
    ImageView qrImageCode;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_qrgenerator);

        qrinput1 = findViewById(R.id.qrInput1);
        qrinput2 = findViewById(R.id.qrInput2);
        qrinput3 = findViewById(R.id.qrInput3);
        qrinput4 = findViewById(R.id.qrInput4);
        qrinput5 = findViewById(R.id.qrInput5);

        generateqrBtn = findViewById(R.id.btn_generateQR);
        qrImageCode = findViewById(R.id.qrcode);

        generateqrBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String data = qrinput5.getText().toString();
                String data5 = qrinput1.getText().toString();
                if(data.isEmpty()){
                    qrinput1.setError("Value Required.");
                }else {
                    QRGEncoder qrgEncoder5 = new QRGEncoder(data, null, com.bangkit.tagme.QRGContents.Type.TEXT, 500);
                    QRGEncoder qrgEncoder = new QRGEncoder(data5, null, com.bangkit.tagme.QRGContents.Type.TEXT, 500);
                    try {
                        Bitmap bitmap5 = qrgEncoder5.encodeAsBitmap();
                        Bitmap bitmap = qrgEncoder.encodeAsBitmap();
                        qrImageCode.setImageBitmap(bitmap5);
                        qrImageCode.setImageBitmap(bitmap);
                    } catch (WriterException e) {
                        e.printStackTrace();

                    }
                }
            }
        });

    }
}
