package com.bangkit.tagme.activity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.bangkit.tagme.MainActivity;
import com.bangkit.tagme.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class SignUpActivity extends AppCompatActivity {


    private EditText mEmailEdt;
    private EditText mPassEdt, mConfirmPassEdt;
    private Button btnRegist;

    private ProgressDialog mDialog;

    //Firebase...
    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);

        mAuth=FirebaseAuth.getInstance();

        mDialog=new ProgressDialog(this);

        registration();
    }

    private void registration(){

        mEmailEdt=findViewById(R.id.emailInpReg);
        mPassEdt=findViewById(R.id.passInpReg);
        mConfirmPassEdt=findViewById(R.id.confirmPassInpReg);
        btnRegist = findViewById(R.id.buttonSignUp);


        btnRegist.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String email=mEmailEdt.getText().toString().trim();
                String pass=mPassEdt.getText().toString().trim();
                String confirmPass=mConfirmPassEdt.getText().toString().trim();

                if (TextUtils.isEmpty(email)){
                    mEmailEdt.setError("Email Required..");
                    return;
                }
                if (TextUtils.isEmpty(pass)){
                    mPassEdt.setError("Password Required..");
                }
                if (TextUtils.isEmpty(confirmPass)){
                    mConfirmPassEdt.setError("Confirm Password Required..");
                }

                mDialog.setMessage("Processing..");
                mDialog.show();

                mAuth.createUserWithEmailAndPassword(email,pass).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {

                        if (task.isSuccessful()){

                            mDialog.dismiss();
                            Toast.makeText(getApplicationContext(),"Registration Complete..",Toast.LENGTH_SHORT).show();
                            startActivity(new Intent(getApplicationContext(), MainActivity.class));

                        }else {
                            mDialog.dismiss();
                            Toast.makeText(getApplicationContext(),"Registration Failed..",Toast.LENGTH_SHORT).show();
                        }

                    }
                });
            }
        });

    }
}
